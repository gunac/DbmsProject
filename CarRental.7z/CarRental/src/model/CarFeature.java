package model;

import javax.persistence.Entity;

@Entity
public class CarFeature {
	
	private int FeatureId;
	private String Description;
	
	public int getFeatureId() {
		return FeatureId;
	}
	public void setFeatureId(int featureId) {
		FeatureId = featureId;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public CarFeature() {
		super();
	}
	public CarFeature(int featureId, String description) {
		super();
		FeatureId = featureId;
		Description = description;
	}	
	public CarFeature(String description) {
		super();
		Description = description;
	}
}
